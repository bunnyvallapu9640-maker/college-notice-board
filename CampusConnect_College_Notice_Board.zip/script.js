const KEY = "campusconnect_notices_v1";
const $ = id => document.getElementById(id);

const seed = [
  {id:"n1",title:"Mid-Semester Examination Schedule Released",department:"CSE",category:"Exam",date:"2026-10-07",important:true,description:"The mid-semester examination schedule has been published. Students are requested to check the timetable and report any discrepancies to the department office.",attachment:null},
  {id:"n2",title:"Innovation & Project Expo 2026",department:"GENERAL",category:"Event",date:"2026-10-06",important:true,description:"Registrations are now open for the annual Innovation & Project Expo. Teams can submit their project abstracts through the department coordinator.",attachment:null},
  {id:"n3",title:"Campus Placement Drive – Software Roles",department:"IT",category:"Placement",date:"2026-10-05",important:false,description:"A campus recruitment drive for software engineering roles will be conducted next week. Eligible final-year students should register before the deadline.",attachment:null},
  {id:"n4",title:"Department Seminar: AI and Future Technologies",department:"ECE",category:"Academic",date:"2026-10-03",important:false,description:"The ECE department is conducting a technical seminar on artificial intelligence and emerging technologies. All interested students are welcome.",attachment:null}
];

let notices = loadNotices();
let loggedIn = sessionStorage.getItem("cc_admin") === "true";

function loadNotices(){
  try {
    const saved = JSON.parse(localStorage.getItem(KEY));
    return Array.isArray(saved) ? saved : seed;
  } catch { return seed; }
}
function save(){ localStorage.setItem(KEY, JSON.stringify(notices)); }
function escapeHTML(s=""){ return String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c])); }
function formatDate(d){ return new Date(d+"T00:00:00").toLocaleDateString(undefined,{day:"2-digit",month:"short",year:"numeric"}); }
function deptName(d){ return d==="GENERAL" ? "All Students" : d; }

function renderStudent(){
  const q=$("searchInput").value.trim().toLowerCase();
  const dept=$("departmentFilter").value, cat=$("categoryFilter").value;
  const filtered=notices.filter(n=>
    (dept==="ALL" || n.department===dept || n.department==="GENERAL") &&
    (cat==="ALL" || n.category===cat) &&
    (!q || `${n.title} ${n.description} ${n.department} ${n.category}`.toLowerCase().includes(q))
  ).sort((a,b)=>new Date(b.date)-new Date(a.date));
  $("noticeCount").textContent=notices.length;
  $("resultText").textContent=`Showing ${filtered.length} of ${notices.length} notices`;
  $("noticeGrid").innerHTML=filtered.map(n=>`
    <article class="notice-card">
      <div class="notice-meta">
        <span class="badge">${escapeHTML(deptName(n.department))}</span>
        <span class="badge">${escapeHTML(n.category)}</span>
        ${n.important?'<span class="badge important">★ Important</span>':""}
        <span class="date">${formatDate(n.date)}</span>
      </div>
      <h4>${escapeHTML(n.title)}</h4>
      <p>${escapeHTML(n.description)}</p>
      ${n.attachment ? `<a class="attachment" href="${n.attachment.data}" download="${escapeHTML(n.attachment.name)}">📎 ${escapeHTML(n.attachment.name)}</a>` : ""}
    </article>`).join("");
  $("emptyState").classList.toggle("hidden", filtered.length!==0);
}

function renderAdmin(){
  $("adminCount").textContent=notices.length;
  $("adminList").innerHTML=notices.slice().sort((a,b)=>new Date(b.date)-new Date(a.date)).map(n=>`
    <div class="admin-item">
      <div><h4>${escapeHTML(n.title)}</h4><p>${escapeHTML(deptName(n.department))} • ${escapeHTML(n.category)} • ${formatDate(n.date)} ${n.important?"• ★ Important":""}</p></div>
      <div class="item-actions">
        <button class="edit-btn" onclick="editNotice('${n.id}')">Edit</button>
        <button class="delete-btn" onclick="deleteNotice('${n.id}')">Delete</button>
      </div>
    </div>`).join("");
}

function showToast(msg){
  $("toast").textContent=msg;$("toast").classList.add("show");
  setTimeout(()=>$("toast").classList.remove("show"),2500);
}
function switchView(id){
  document.querySelectorAll(".view").forEach(v=>v.classList.remove("active-view"));
  $(id).classList.add("active-view");
  document.querySelectorAll(".nav-btn").forEach(b=>b.classList.toggle("active",b.dataset.view===id));
  if(id==="adminView") renderAdminAuth();
}
function renderAdminAuth(){
  $("loginPanel").classList.toggle("hidden",loggedIn);
  $("adminPanel").classList.toggle("hidden",!loggedIn);
  if(loggedIn) renderAdmin();
}
function resetForm(){
  $("noticeForm").reset(); $("editId").value=""; $("date").value=new Date().toISOString().slice(0,10);
  $("formTitle").textContent="Publish a Notice"; $("cancelEdit").classList.add("hidden"); $("currentAttachment").textContent="";
}

document.querySelectorAll(".nav-btn").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
["searchInput","departmentFilter","categoryFilter"].forEach(id=>$(id).addEventListener("input",renderStudent));
$("clearFilters").addEventListener("click",()=>{$("searchInput").value="";$("departmentFilter").value="ALL";$("categoryFilter").value="ALL";renderStudent()});

$("loginForm").addEventListener("submit",e=>{
  e.preventDefault();
  if($("username").value==="admin" && $("password").value==="admin123"){
    loggedIn=true;sessionStorage.setItem("cc_admin","true");$("loginError").textContent="";renderAdminAuth();showToast("Welcome, Administrator");
  } else $("loginError").textContent="Invalid username or password.";
});
$("logoutBtn").addEventListener("click",()=>{loggedIn=false;sessionStorage.removeItem("cc_admin");renderAdminAuth();showToast("Logged out successfully")});
$("cancelEdit").addEventListener("click",resetForm);

$("noticeForm").addEventListener("submit",async e=>{
  e.preventDefault();
  const file=$("attachment").files[0];
  let attachment=null;
  if(file){
    if(file.size>2*1024*1024){showToast("Attachment must be under 2 MB for this demo.");return;}
    attachment=await fileToData(file);
  }
  const id=$("editId").value;
  if(id){
    const old=notices.find(n=>n.id===id);
    Object.assign(old,{
      title:$("title").value.trim(),department:$("department").value,category:$("category").value,
      date:$("date").value,important:$("important").checked,description:$("description").value.trim(),
      attachment:attachment || old.attachment
    });
    showToast("Notice updated");
  }else{
    notices.push({id:"n"+Date.now(),title:$("title").value.trim(),department:$("department").value,category:$("category").value,date:$("date").value,important:$("important").checked,description:$("description").value.trim(),attachment});
    showToast("Notice published");
  }
  save();resetForm();renderStudent();renderAdmin();
});
function fileToData(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve({name:file.name,type:file.type,data:r.result});r.onerror=reject;r.readAsDataURL(file)})}

window.editNotice=function(id){
  const n=notices.find(x=>x.id===id); if(!n)return;
  $("editId").value=n.id;$("title").value=n.title;$("department").value=n.department;$("category").value=n.category;
  $("date").value=n.date;$("important").checked=n.important;$("description").value=n.description;
  $("formTitle").textContent="Edit Notice";$("cancelEdit").classList.remove("hidden");
  $("currentAttachment").textContent=n.attachment?`Current attachment: ${n.attachment.name}`:"No attachment";
  window.scrollTo({top:0,behavior:"smooth"});
};
window.deleteNotice=function(id){
  const n=notices.find(x=>x.id===id);
  if(!n || !confirm(`Delete "${n.title}"?`)) return;
  notices=notices.filter(x=>x.id!==id);save();renderStudent();renderAdmin();showToast("Notice deleted");
};

$("date").value=new Date().toISOString().slice(0,10);
renderStudent();renderAdminAuth();
