# CampusConnect – College Digital Notice Board

A hackathon-ready frontend prototype built with:
- HTML5
- CSS3
- Vanilla JavaScript
- Browser localStorage/sessionStorage

No Python. No Flask. No backend server is required.

## Demo login
Username: admin
Password: admin123

## Run
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Use Student Portal to search/filter notices.
4. Use Admin Portal to sign in and create/edit/delete notices.

## Features
- Student notice board
- Department filtering
- Category filtering
- Search
- Important notice badges
- Admin login
- Create, edit and delete notices
- PDF/image/DOC/TXT attachment support
- Attachment download
- Responsive mobile layout
- Demo data
- Persistent notices with localStorage

## Important hackathon note
This is a client-side prototype. The admin credentials and data are stored in the browser, so this is NOT production-grade authentication.

For a real college deployment, connect the same UI to Firebase/Supabase/another backend for:
- secure authentication
- cloud file storage
- shared notices across devices
- role-based access
- audit logs
